#!/usr/bin/env python3
"""Agnes-Video-V2.0 client.

Submit a video generation task, poll until completion, and download the result.

Usage examples:

  # text -> video
  python agnes_video.py text2video --prompt "A cat on the beach" \
      --duration 3s --out cat.mp4

  # single image -> video
  python agnes_video.py image2video --prompt "She turns and looks back" \
      --image https://example.com/a.png --out turn.mp4

  # multiple reference images -> video
  python agnes_video.py multi-image --prompt "Smooth transformation" \
      --image https://example.com/1.png --image https://example.com/2.png \
      --out morph.mp4

  # keyframe animation (start frame -> end frame)
  python agnes_video.py keyframes --prompt "Smooth transition" \
      --image https://example.com/start.png --image https://example.com/end.png \
      --out kf.mp4

The API key is read in this order:
  1. --api-key flag
  2. AGNES_API_KEY environment variable
  3. The first AGNES_API_KEY=... line found in any --env-file path
  4. C:/Users/<user>/agnes.env (if it exists)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

API_BASE = "https://apihub.agnes-ai.com"
CREATE_ENDPOINT = f"{API_BASE}/v1/videos"
QUERY_ENDPOINT = f"{API_BASE}/agnesapi"
MODEL_NAME = "agnes-video-v2.0"

MAX_FRAMES = 441
FRAME_RATE_MIN = 1
FRAME_RATE_MAX = 30


# ---------- key + env helpers ----------

def _read_env_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return out
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        out[key.strip()] = value.strip().strip('"').strip("'")
    return out


def resolve_api_key(cli_key: str | None, env_files: list[str]) -> str:
    if cli_key:
        return cli_key.strip()
    env_key = os.environ.get("AGNES_API_KEY")
    if env_key:
        return env_key.strip()
    candidates: list[Path] = [Path(p) for p in env_files]
    home = Path.home() / "agnes.env"
    if home.exists():
        candidates.append(home)
    for p in candidates:
        data = _read_env_file(p)
        if data.get("AGNES_API_KEY"):
            return data["AGNES_API_KEY"]
    raise SystemExit(
        "ERROR: no API key found. Pass --api-key, set AGNES_API_KEY, "
        "or put AGNES_API_KEY=... in ~/agnes.env or a file passed via --env-file."
    )


# ---------- frames / aspect helpers ----------

ASPECT_PRESETS: dict[str, tuple[int, int]] = {
    "16:9": (1152, 768),   # default landscape
    "9:16": (768, 1152),
    "1:1": (960, 960),
    "4:3": (1024, 768),
    "3:4": (768, 1024),
}

DURATION_PRESETS: dict[str, tuple[int, int]] = {
    # label -> (num_frames, frame_rate)
    "3s": (81, 24),
    "5s": (121, 24),
    "10s": (241, 24),
    "18s": (441, 24),
}


def normalize_frames(num_frames: int) -> int:
    """Snap to the nearest valid 8n+1 value, capped at MAX_FRAMES."""
    if num_frames < 9:
        num_frames = 9
    # Round to nearest 8n+1
    n = round((num_frames - 1) / 8)
    snapped = 8 * n + 1
    if snapped > MAX_FRAMES:
        snapped = MAX_FRAMES
    if snapped < 9:
        snapped = 9
    return snapped


def validate_frames(num_frames: int) -> None:
    if num_frames > MAX_FRAMES:
        raise SystemExit(f"ERROR: num_frames must be <= {MAX_FRAMES}")
    if (num_frames - 1) % 8 != 0:
        raise SystemExit("ERROR: num_frames must satisfy 8n+1 (e.g. 81, 121, 241, 441)")


def validate_fps(fps: float) -> None:
    if not (FRAME_RATE_MIN <= fps <= FRAME_RATE_MAX):
        raise SystemExit(f"ERROR: frame_rate must be within [{FRAME_RATE_MIN}, {FRAME_RATE_MAX}]")


# ---------- HTTP ----------

def _request(method: str, url: str, api_key: str, body: dict | None = None,
             timeout: int = 60) -> dict[str, Any]:
    data = None
    headers = {"Authorization": f"Bearer {api_key}"}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        body_text = e.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {e.code} {e.reason}: {body_text}") from e
    except urllib.error.URLError as e:
        raise SystemExit(f"Network error: {e.reason}") from e
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        raise SystemExit(f"Invalid JSON from {url}: {raw[:500]}") from e


def create_task(api_key: str, payload: dict) -> dict:
    return _request("POST", CREATE_ENDPOINT, api_key, body=payload, timeout=60)


def query_task(api_key: str, video_id: str) -> dict:
    qs = urllib.parse.urlencode({"video_id": video_id, "model_name": MODEL_NAME})
    return _request("GET", f"{QUERY_ENDPOINT}?{qs}", api_key, timeout=30)


def poll_until_done(api_key: str, video_id: str, *, interval: float = 5.0,
                    timeout_s: float = 1800.0, log=print) -> dict:
    start = time.time()
    last_progress = -1
    while True:
        info = query_task(api_key, video_id)
        status = info.get("status")
        progress = info.get("progress")
        if progress != last_progress:
            log(f"[{int(time.time() - start)}s] status={status} progress={progress}")
            last_progress = progress
        if status == "completed":
            return info
        if status == "failed":
            raise SystemExit(f"Task failed: {json.dumps(info, ensure_ascii=False)}")
        if time.time() - start > timeout_s:
            raise SystemExit(f"Timeout after {timeout_s:.0f}s; last={json.dumps(info)}")
        time.sleep(interval)


def download(url: str, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url, timeout=120) as resp, open(out_path, "wb") as f:
        while True:
            chunk = resp.read(1 << 16)
            if not chunk:
                break
            f.write(chunk)


# ---------- payload builder ----------

def build_payload(args: argparse.Namespace) -> dict:
    # resolve duration
    if args.duration:
        if args.duration not in DURATION_PRESETS:
            raise SystemExit(
                f"ERROR: --duration must be one of {sorted(DURATION_PRESETS)}; "
                "use --num-frames/--frame-rate for full control."
            )
        num_frames, frame_rate = DURATION_PRESETS[args.duration]
    else:
        num_frames = args.num_frames if args.num_frames is not None else 121
        frame_rate = args.frame_rate if args.frame_rate is not None else 24

    if args.snap_frames:
        num_frames = normalize_frames(num_frames)
    validate_frames(num_frames)
    validate_fps(frame_rate)

    # resolve aspect / size
    if args.size:
        try:
            w_str, h_str = args.size.lower().split("x")
            width, height = int(w_str), int(h_str)
        except Exception as e:
            raise SystemExit("ERROR: --size must look like 1152x768") from e
    elif args.aspect:
        if args.aspect not in ASPECT_PRESETS:
            raise SystemExit(f"ERROR: --aspect must be one of {sorted(ASPECT_PRESETS)}")
        width, height = ASPECT_PRESETS[args.aspect]
    else:
        width, height = 1152, 768

    payload: dict[str, Any] = {
        "model": MODEL_NAME,
        "prompt": args.prompt,
        "width": width,
        "height": height,
        "num_frames": num_frames,
        "frame_rate": frame_rate,
    }
    if args.negative_prompt:
        payload["negative_prompt"] = args.negative_prompt
    if args.seed is not None:
        payload["seed"] = args.seed
    if args.steps is not None:
        payload["num_inference_steps"] = args.steps

    images = list(args.image or [])

    if args.command == "text2video":
        if images:
            raise SystemExit("text2video does not accept --image; use image2video instead.")
    elif args.command == "image2video":
        if len(images) != 1:
            raise SystemExit("image2video requires exactly one --image URL.")
        payload["image"] = images[0]
    elif args.command == "multi-image":
        if len(images) < 2:
            raise SystemExit("multi-image requires at least two --image URLs.")
        payload["extra_body"] = {"image": images}
    elif args.command == "keyframes":
        if len(images) < 2:
            raise SystemExit("keyframes requires at least two --image URLs (start, end, ...).")
        payload["extra_body"] = {"image": images, "mode": "keyframes"}
    else:
        raise SystemExit(f"Unknown command: {args.command}")

    return payload


# ---------- CLI ----------

def add_common(p: argparse.ArgumentParser) -> None:
    p.add_argument("--prompt", required=True, help="Text description of the video")
    p.add_argument("--negative-prompt", help="Things to avoid")
    p.add_argument("--image", action="append", default=[],
                   help="Image URL (repeat for multi-image / keyframes)")
    p.add_argument("--duration", choices=sorted(DURATION_PRESETS),
                   help="Duration preset (overrides --num-frames/--frame-rate)")
    p.add_argument("--num-frames", type=int, help="Custom frame count, must satisfy 8n+1, <=441")
    p.add_argument("--frame-rate", type=float, help="FPS, 1..30")
    p.add_argument("--snap-frames", action="store_true",
                   help="Snap --num-frames to the nearest valid 8n+1 value")
    p.add_argument("--aspect", choices=sorted(ASPECT_PRESETS), help="Aspect preset")
    p.add_argument("--size", help="Explicit WxH, e.g. 1152x768 (overrides --aspect)")
    p.add_argument("--seed", type=int, help="Random seed for reproducibility")
    p.add_argument("--steps", type=int, help="Number of inference steps")
    p.add_argument("--out", help="Where to save the resulting mp4 (optional)")
    p.add_argument("--api-key", help="API key (else AGNES_API_KEY / ~/agnes.env)")
    p.add_argument("--env-file", action="append", default=[], help="Extra env file path")
    p.add_argument("--poll-interval", type=float, default=5.0)
    p.add_argument("--timeout", type=float, default=1800.0,
                   help="Max seconds to wait for the task to finish")
    p.add_argument("--no-wait", action="store_true",
                   help="Submit only; print video_id and exit")
    p.add_argument("--json", action="store_true", help="Print final result as JSON only")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Agnes-Video-V2.0 client")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("text2video", "image2video", "multi-image", "keyframes"):
        sp = sub.add_parser(name)
        add_common(sp)
    args = parser.parse_args(argv)

    api_key = resolve_api_key(args.api_key, args.env_file)
    payload = build_payload(args)

    if not args.json:
        print(f"Submitting {args.command} task -> {CREATE_ENDPOINT}")
    created = create_task(api_key, payload)
    video_id = created.get("video_id") or created.get("id")
    if not video_id:
        raise SystemExit(f"No video_id in response: {created}")

    if args.no_wait:
        print(json.dumps(created, ensure_ascii=False, indent=2))
        return 0

    if not args.json:
        print(f"video_id = {video_id}")
        print(f"requested size {payload['width']}x{payload['height']}, "
              f"actual size {created.get('size')}, est seconds {created.get('seconds')}")

    final = poll_until_done(
        api_key, video_id,
        interval=args.poll_interval, timeout_s=args.timeout,
        log=(lambda *a, **kw: None) if args.json else print,
    )
    url = final.get("remixed_from_video_id")
    if not url:
        raise SystemExit(f"completed but no video URL: {final}")

    if args.out:
        out = Path(args.out)
        if not args.json:
            print(f"Downloading -> {out}")
        download(url, out)
        final["local_path"] = str(out)

    if args.json:
        print(json.dumps(final, ensure_ascii=False, indent=2))
    else:
        print(f"Done. URL: {url}")
        if args.out:
            print(f"Saved to: {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
