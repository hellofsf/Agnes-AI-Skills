# Agnes-Video-V2.0 API Reference

A clean, English-language reference rebuilt from the official Agnes AI docs. Use this when SKILL.md does not have the answer.

## Endpoints

| Purpose | Method | URL |
| --- | --- | --- |
| Create task | POST | `https://apihub.agnes-ai.com/v1/videos` |
| Query result (recommended) | GET | `https://apihub.agnes-ai.com/agnesapi?video_id=<VIDEO_ID>&model_name=agnes-video-v2.0` |
| Query result (legacy) | GET | `https://apihub.agnes-ai.com/v1/videos/<TASK_ID>` |

Auth header for every call: `Authorization: Bearer <API_KEY>`. POST body is `application/json`.

## Capabilities

| Mode | What it does | Required inputs |
| --- | --- | --- |
| text2video | Generate a video from text only | `prompt` |
| image2video | Animate a single image | `prompt`, `image` (URL string) |
| multi-image | Use multiple reference images | `prompt`, `extra_body.image` (>=2 URLs) |
| keyframes | Smooth animation between keyframes | `prompt`, `extra_body.image` (>=2 URLs), `extra_body.mode = "keyframes"` |

## Create-task body parameters

| Field | Type | Required | Notes |
| --- | --- | --- | --- |
| model | string | yes | Must be `agnes-video-v2.0` |
| prompt | string | yes | Text description |
| image | string \| string[] | no | Image URL(s) for image2video |
| height | int | no | Default 768 |
| width | int | no | Default 1152 |
| num_frames | int | no | Must be `<= 441` AND satisfy `8n+1` |
| frame_rate | number | no | 1..30 |
| num_inference_steps | int | no | Inference steps |
| seed | int | no | For reproducibility |
| negative_prompt | string | no | Things to avoid |
| extra_body.image | string[] | no | Multi-image / keyframes inputs |
| extra_body.mode | string | no | e.g. `keyframes` |

The server snaps `width`/`height`/aspect to one of the supported resolution tiers (480p / 720p / 1080p) and aspect ratios (16:9, 9:16, 1:1, 4:3, 3:4). Treat the response's `size` and `seconds` as the source of truth, not the values you sent.

## Frame and duration math

```
seconds = num_frames / frame_rate
num_frames in {9, 17, 25, ..., 441}   (i.e. 8n + 1, n >= 1)
frame_rate in [1, 30]
```

Common presets:

| Target | num_frames | frame_rate |
| --- | --- | --- |
| ~3s | 81 | 24 |
| ~5s | 121 | 24 |
| ~10s | 241 | 24 |
| ~18s | 441 | 24 |

## Aspect presets (recommended starting sizes)

| Aspect | Use cases | Suggested WxH |
| --- | --- | --- |
| 16:9 | Landscape / YouTube / product demos | 1152x768 |
| 9:16 | Reels / Shorts / TikTok | 768x1152 |
| 1:1 | Social feeds, square ads | 960x960 |
| 4:3 | Traditional displays | 1024x768 |
| 3:4 | Portrait product / character | 768x1024 |

## Response: create-task

```json
{
  "id": "task_xxx",
  "task_id": "task_xxx",
  "video_id": "video_xxx",
  "object": "video",
  "model": "agnes-video-v2.0",
  "status": "queued",
  "progress": 0,
  "created_at": 1780457477,
  "seconds": "10.0",
  "size": "1280x768"
}
```

`video_id` is the recommended handle for querying results. `task_id` still works on the legacy endpoint.

## Response: query result

While running:

```json
{ "status": "in_progress", "progress": 30, ... }
```

When done:

```json
{
  "status": "completed",
  "progress": 100,
  "remixed_from_video_id": "https://platform-outputs.agnes-ai.space/.../video_xxx.mp4",
  "seconds": "3.4",
  "size": "1088x832",
  "error": null
}
```

The final mp4 URL lives in `remixed_from_video_id` and is only present when `status == "completed"`.

## Status values

| Status | Meaning |
| --- | --- |
| queued | Waiting in queue |
| in_progress | Generating |
| completed | Done; mp4 available |
| failed | Generation failed; see `error` |

## Error codes

| Code | Meaning |
| --- | --- |
| 400 | Bad request / invalid params |
| 401 | Unauthorized; check API key |
| 404 | Task or video not found |
| 500 | Server error |
| 503 | Server busy; retry later |

## Prompt patterns

Text-to-video skeleton:

```
[subject] + [action] + [scene] + [camera move] + [lighting] + [style]
```

Example:

```
A young astronaut walking across a red desert planet, dust blowing in the wind, slow cinematic tracking shot, dramatic sunset lighting, realistic sci-fi style
```

Image-to-video: describe what should move and what must stay stable (face, outfit, background).

Multi-image: describe the relationship between images and how to transition.

Keyframes: explicitly describe the transition between frame 1 and frame 2 (camera, subject identity, motion).

## Polling guidance

- Poll every 5 seconds.
- Typical 3s clip completes in 1-2 minutes; longer clips proportionally longer.
- Treat anything over `--timeout` (default 1800s) as a failure for retry purposes.
