---
name: agnes-video-gen
description: Generate videos using the Agnes-Video-V2.0 model via the Agnes AI API. Use whenever the user asks to create, generate, make, render, or produce a video, animation, or motion clip - including text-to-video, image-to-video, multi-image video, keyframe animation, product demo video, social-media short (Reels / Shorts / TikTok), cinematic clip, scene transition, or animating a still image. This skill handles task creation, polling, and downloading the final mp4 through scripts/agnes_video.py and the agnes-video-v2.0 model.
---

# Agnes Video Generation

## Overview

Agnes-Video-V2.0 is an asynchronous video generation API. This skill wraps the full lifecycle (submit task -> poll -> download mp4) inside `scripts/agnes_video.py`, so other Codex turns just choose a mode and prompt.

Always prefer this skill (and the bundled script) over hand-rolling `curl` calls when the user asks for video generation.

## When to use which mode

| User intent | Mode | Required inputs |
| --- | --- | --- |
| "Make a video of ..." (no image) | `text2video` | prompt |
| "Animate this image" / single image -> video | `image2video` | prompt + 1 image URL |
| "Use these images as references" (>=2) | `multi-image` | prompt + 2+ image URLs |
| "Tween between these keyframes" / "transition from A to B" | `keyframes` | prompt + 2+ image URLs |

## Quick start

The script is at `scripts/agnes_video.py`. The API key is read in this order: `--api-key`, `AGNES_API_KEY` env var, any path passed via `--env-file`, then `~/agnes.env`. If the user keeps the key at `~/agnes.env` (e.g. `C:\Users\<you>\agnes.env` on Windows), it is auto-discovered.

Run from the skill folder (or pass an absolute path to the script).

Text-to-video, ~3s clip, 16:9, save locally:

```bash
python scripts/agnes_video.py text2video \
  --prompt "A cinematic shot of a cat walking on the beach at sunset, soft ocean waves, warm golden lighting" \
  --duration 3s --aspect 16:9 \
  --out outputs/cat.mp4
```

Image-to-video:

```bash
python scripts/agnes_video.py image2video \
  --prompt "She slowly turns and looks back at the camera, gentle wind, cinematic" \
  --image https://example.com/portrait.png \
  --duration 5s --aspect 9:16 \
  --out outputs/turn.mp4
```

Multi-image:

```bash
python scripts/agnes_video.py multi-image \
  --prompt "Use the first image as the start scene and the second as the target; smooth cinematic transformation" \
  --image https://example.com/a.png --image https://example.com/b.png \
  --duration 5s --out outputs/morph.mp4
```

Keyframes:

```bash
python scripts/agnes_video.py keyframes \
  --prompt "Smooth transition from the first keyframe to the second; consistent identity, natural camera move" \
  --image https://example.com/k1.png --image https://example.com/k2.png \
  --duration 5s --out outputs/transition.mp4
```

## Parameter rules (must respect)

- `num_frames` must be `<= 441` AND satisfy `8n + 1` (e.g. 81, 121, 241, 441). The script validates this and can `--snap-frames` to the nearest valid value.
- `frame_rate` must be in `[1, 30]`.
- The server normalizes width/height/aspect to a supported tier (480p / 720p / 1080p) and one of: 16:9, 9:16, 1:1, 4:3, 3:4. Always report the `size` from the API response, not the requested values.
- The final mp4 URL lives in `remixed_from_video_id` and is only present when `status == "completed"`.

## Duration presets

`--duration` is the easy lever. It overrides `--num-frames` and `--frame-rate`.

| `--duration` | num_frames | frame_rate | clip length |
| --- | --- | --- | --- |
| `3s` | 81 | 24 | ~3.4s |
| `5s` | 121 | 24 | ~5s |
| `10s` | 241 | 24 | ~10s |
| `18s` | 441 | 24 | ~18s |

For finer control, drop `--duration` and pass `--num-frames` + `--frame-rate` explicitly. Add `--snap-frames` if the user gives a number that is not 8n+1.

## Aspect presets

| `--aspect` | Best for |
| --- | --- |
| `16:9` (default) | Landscape, product demos, YouTube |
| `9:16` | Reels / Shorts / TikTok |
| `1:1` | Square social feed |
| `4:3` | Traditional displays |
| `3:4` | Portrait products / characters |

Or use `--size 1152x768` to override.

## Workflow guidance

1. Pick the mode from the table above.
2. Choose `--duration` (default to `5s` if the user has no preference).
3. Choose `--aspect` based on the platform the user mentions; default to `16:9`.
4. Always pass `--out <path>.mp4` so the file is saved locally; pick a path under the user's project unless they say otherwise.
5. Run the script. It prints periodic status lines and finally the URL + local path.
6. Surface the final URL and `<saved-path>` to the user. If the script exits non-zero, show the error verbatim and stop; do not retry blindly.

If the task takes more than `--timeout` seconds (default 1800), the script raises. Do not silently retry; report the timeout and ask the user whether to retry with a shorter clip.

## Useful flags

- `--no-wait`: submit only, print the JSON response with `video_id`, then exit. Use this when the user wants to fire-and-forget.
- `--json`: print only the final JSON result (no progress logs). Use when chaining into another tool.
- `--negative-prompt "..."`: avoid unwanted content.
- `--seed <int>`: reproducible result.
- `--steps <int>`: more inference steps (slower, sometimes higher quality).
- `--poll-interval 10`: slow down polling for very long jobs.
- `--env-file <path>`: read `AGNES_API_KEY` from a custom dotenv-style file.

## Prompt tips

Text-to-video skeleton: `[subject] + [action] + [scene] + [camera move] + [lighting] + [style]`.

For image2video, describe what should move and what must stay stable (face, outfit, background).

For multi-image and keyframes, describe the relationship between the inputs and how to transition (camera angle, identity, pacing).

When in doubt about the API itself (fields, status codes, response shape), read [references/api.md](references/api.md).

## Resources

- `scripts/agnes_video.py` - the canonical client. Always prefer this over raw `curl` so validation and polling are consistent.
- `references/api.md` - clean English reference for the underlying HTTP API.
