#!/usr/bin/env python3
"""Agnes-Image-2.0-Flash CLI for the agnes-image skill.

Reads AGNES_API_KEY from (in order):
  1. process env var AGNES_API_KEY
  2. --env-file PATH
  3. $AGNES_ENV_FILE
  4. ~/.agnes/agnes.env

The key is never written to disk by this script and never appears in skill
sources. If it is missing the script exits with a clear error.

Usage:
  python generate.py --prompt "..." [--size 1024x768] [--output out.png]
                     [--image URL_OR_DATAURI ...] [--format url|b64_json]
                     [--return-base64] [--env-file PATH]
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

DEFAULT_ENV_FILE = Path.home() / ".agnes" / "agnes.env"
ENDPOINT = "https://apihub.agnes-ai.com/v1/images/generations"
MODEL = "agnes-image-2.0-flash"


def load_api_key(env_file: Optional[str]) -> str:
    key = os.environ.get("AGNES_API_KEY")
    if key:
        return key.strip()

    candidates = []
    if env_file:
        candidates.append(Path(env_file))
    if os.environ.get("AGNES_ENV_FILE"):
        candidates.append(Path(os.environ["AGNES_ENV_FILE"]))
    candidates.append(DEFAULT_ENV_FILE)

    for path in candidates:
        try:
            if not path.is_file():
                continue
        except OSError:
            continue
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            k, v = line.split("=", 1)
            if k.strip() == "AGNES_API_KEY":
                return v.strip().strip('"').strip("'")

    sys.stderr.write(
        "ERROR: AGNES_API_KEY not found.\n"
        "Provide it via one of:\n"
        "  - env var AGNES_API_KEY\n"
        "  - --env-file PATH (file containing 'AGNES_API_KEY=sk-...')\n"
        "  - env var AGNES_ENV_FILE pointing to such a file\n"
        f"  - default file: {DEFAULT_ENV_FILE}\n"
    )
    sys.exit(2)


def call_api(payload: dict, api_key: str) -> dict:
    req = urllib.request.Request(
        ENDPOINT,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:1000]
        sys.stderr.write(f"HTTP {e.code} from agnes-ai: {body}\n")
        sys.exit(3)
    except urllib.error.URLError as e:
        sys.stderr.write(f"Network error calling agnes-ai: {e}\n")
        sys.exit(4)


def save_image(data_item: dict, output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    if data_item.get("b64_json"):
        output.write_bytes(base64.b64decode(data_item["b64_json"]))
        return output
    url = data_item.get("url")
    if not url:
        sys.stderr.write("Response had neither b64_json nor url.\n")
        sys.exit(5)
    try:
        with urllib.request.urlopen(url, timeout=180) as r:
            output.write_bytes(r.read())
    except urllib.error.URLError as e:
        sys.stderr.write(f"Failed to download image url: {e}\n")
        sys.exit(6)
    return output


def main() -> None:
    p = argparse.ArgumentParser(description="Generate images via agnes-image-2.0-flash")
    p.add_argument("--prompt", required=True, help="Text prompt")
    p.add_argument("--size", default="1024x1024", help="e.g. 1024x768, 1024x1024, 768x1024")
    p.add_argument("--output", default="agnes_output.png", help="Output PNG path")
    p.add_argument(
        "--image",
        action="append",
        default=[],
        help="Reference image URL or data URI (repeatable). Triggers img2img / multi-image.",
    )
    p.add_argument(
        "--format",
        choices=["url", "b64_json"],
        default="url",
        help="response_format passed in extra_body (default: url)",
    )
    p.add_argument(
        "--return-base64",
        action="store_true",
        help="Set return_base64=true (text-to-image only)",
    )
    p.add_argument("--env-file", default=None, help="Path to env file containing AGNES_API_KEY")
    p.add_argument("--print-json", action="store_true", help="Print raw JSON response to stdout")
    args = p.parse_args()

    api_key = load_api_key(args.env_file)

    payload: dict = {
        "model": MODEL,
        "prompt": args.prompt,
        "size": args.size,
        "extra_body": {"response_format": args.format},
    }
    if args.image:
        payload["image"] = list(args.image)
    if args.return_base64 and not args.image:
        payload["return_base64"] = True

    data = call_api(payload, api_key)
    if args.print_json:
        print(json.dumps(data, ensure_ascii=False)[:4000])

    items = data.get("data") or []
    if not items:
        sys.stderr.write(f"No data returned: {json.dumps(data)[:500]}\n")
        sys.exit(7)

    out = Path(args.output).resolve()
    saved = save_image(items[0], out)
    revised = items[0].get("revised_prompt")
    print(f"saved: {saved}")
    if revised:
        print(f"revised_prompt: {revised}")


if __name__ == "__main__":
    main()