---
name: "agnes-image"
description: "Generate or edit raster images via the agnes-image-2.0-flash API (text-to-image, image-to-image, multi-image composite). Use whenever Codex needs to create a brand-new bitmap image, transform an existing image, or derive visual variants from one or more reference images, including photos, illustrations, textures, sprites, mockups, marketing visuals, e-commerce product shots, and social/meme content. This skill replaces the default imagegen flow for any bitmap image generation task. Do not use for tasks better handled by editing existing SVG/vector assets, extending an established icon or logo system, or building the visual directly in HTML/CSS/canvas."
---

# Agnes Image Generation Skill

This skill is the default image-generation path for Codex in this environment. Any task that would otherwise trigger the built-in `imagegen` skill or a generic "make me an image" request must go through this skill instead. It calls `agnes-image-2.0-flash` via an OpenAI-compatible HTTP API.

## When to use

- Generate a brand-new bitmap image from a text prompt (concept art, product shot, hero image, illustration, texture, sprite, mockup, infographic background, etc.).
- Transform an existing image (style transfer, background replacement, object replacement, lighting changes, local edits) by passing it as a reference.
- Composite multiple reference images into a single new scene (multi-image input).

## When not to use

- Extending a repo's existing SVG/vector icon set, logo system, or illustration library.
- Building simple shapes, diagrams, wireframes, or icons that should live as SVG / HTML / CSS / canvas code.
- Editing an asset whose source already exists in an editable native format and the user just wants a code-level tweak.

## API at a glance

- Endpoint: `POST https://apihub.agnes-ai.com/v1/images/generations`
- Auth header: `Authorization: Bearer <AGNES_API_KEY>`
- Model: `agnes-image-2.0-flash`
- Required body fields: `model`, `prompt`, `size`. Add `image: [url_or_data_uri, ...]` for image-to-image or multi-image.
- `response_format` MUST live inside `extra_body` (e.g. `"extra_body": {"response_format": "url"}`).
- Response shape: `data[0].url` and/or `data[0].b64_json`, plus `revised_prompt`.

Common sizes: `1024x1024`, `1024x768`, `768x1024`. Pick the aspect ratio that matches the user's intent (square avatar vs. landscape hero vs. portrait poster).

## Credentials

The bundled `scripts/generate.py` reads `AGNES_API_KEY` at runtime. It looks in this order:

1. Process env var `AGNES_API_KEY`.
2. `--env-file PATH` argument.
3. Env var `AGNES_ENV_FILE` pointing to a file.
4. Default file: `~/.agnes/agnes.env` (i.e. `$HOME/.agnes/agnes.env`).

The env file is a plain text file with one line:

```
AGNES_API_KEY=sk-...
```

Set it up once per machine. Examples:

- macOS / Linux: `mkdir -p ~/.agnes && echo "AGNES_API_KEY=sk-..." > ~/.agnes/agnes.env && chmod 600 ~/.agnes/agnes.env`
- Windows PowerShell: `New-Item -ItemType Directory -Force "$HOME\.agnes" | Out-Null; Set-Content "$HOME\.agnes\agnes.env" "AGNES_API_KEY=sk-..."`

Codex must NEVER hard-code the key, echo it, log it, or copy it into other files. The script is the only place that reads it. If the env file is missing, ask the user to create it; do not paste keys into chat.

## How to invoke

Always use the bundled CLI rather than crafting a one-off `curl` or Python snippet. `$CODEX_HOME` is normally `~/.codex`.

Text-to-image:

```bash
python "$CODEX_HOME/skills/agnes-image/scripts/generate.py" \
    --prompt "A clean product photo of a glass cube on a white studio background, soft shadows, high detail" \
    --size 1024x768 \
    --output ./hero.png
```

Image-to-image / multi-image (repeat `--image`):

```bash
python "$CODEX_HOME/skills/agnes-image/scripts/generate.py" \
    --prompt "Place these two characters on a neon-lit Tokyo street at night, cinematic" \
    --image https://example.com/character-1.png \
    --image https://example.com/character-2.png \
    --size 1024x1024 \
    --output ./scene.png
```

The script downloads `data[0].url` (or decodes `b64_json`) and writes a PNG to `--output`. It prints the saved path and any `revised_prompt`.

## Save-path policy

- If the user names a destination, save there.
- If the image is meant for the current project, save it inside the workspace (e.g. `./assets/...` or another sensible project folder), not under `$CODEX_HOME` or temp.
- For pure preview/brainstorm use, a workspace-local `.tmp_agnes/` folder is fine; clean it up if the user asks.
- Do not overwrite existing assets unless the user asked for replacement; pick a sibling name like `hero-v2.png`.
- After saving, show the image inline in the response with an absolute-path Markdown image tag so the user can actually see it.

## Prompting tips

- Be concrete about subject, composition, lighting, materials, and style; vague prompts produce vague results.
- For product shots, name the surface, background, lens feel, and shadow softness.
- For edits, describe what to keep as well as what to change so the model preserves the right anchor.
- For multi-image composites, say which reference contributes what (subject vs. style vs. environment).
- If the first result misses, iterate on the prompt rather than re-rolling blindly; the API also returns `revised_prompt`, which is useful feedback.

## Failure handling

- HTTP non-2xx: surface the status and message; do not retry blindly. Common causes are a bad `size`, missing `image` for img2img intent, or an invalid key.
- Empty `data`: report the raw response and stop.
- Missing API key: tell the user to populate the env file (see Credentials) and stop; do not prompt them to paste it into chat.
- Network failure: report the error; suggest retry once. Do not silently fall back to another model.